//
//  File.swift
//  
//
//  Created by Mohammad Azam on 3/12/24.
//

import Foundation
import Vapor
import Fluent

final class Movie: Model, Content {
    
    static var schema: String = "movies"
    
    @ID(key: .id)
    var id: UUID?
    
    @Field(key: "name")
    var name: String
    
    // reviews relationship
    @Children(for: \.$movie)
    var reviews: [Review]
    
    init() { }
    
    init(id: UUID? = nil, name: String) {
        self.id = id
        self.name = name 
    }
    
}

extension Movie: Validatable {
    
    static func validations(_ validations: inout Validations) {
        validations.add("name", as: String.self, is: .alphanumeric)
    }
}
