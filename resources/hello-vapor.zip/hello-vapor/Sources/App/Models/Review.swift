//
//  File.swift
//  
//
//  Created by Mohammad Azam on 3/16/24.
//

import Foundation
import Vapor
import Fluent

final class Review: Model, Content {
    
    static var schema: String = "reviews"
    
    @ID(key: .id)
    var id: UUID?
    
    @Field(key: "subject")
    var subject: String
    
    @Field(key: "description")
    var description: String
        
    // belongTo relationship
    @Parent(key: "movie_id")
    var movie: Movie
    
    init() { }
    
    init(id: UUID? = nil, subject: String, description: String, movieId: Movie.IDValue) {
        self.id = id
        self.subject = subject
        self.description = description
        self.$movie.id = movieId
    }
    
}
