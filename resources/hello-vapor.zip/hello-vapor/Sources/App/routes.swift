import Vapor
import Fluent
import FluentPostgresDriver
import SQLKit

func routes(_ app: Application) throws {
    
    try app.register(collection: MoviesController())
    
    app.get("foo") { req async throws -> String in
        
        guard let sql = req.db as? SQLDatabase else {
            throw Abort(.internalServerError)
        }
        
        let result = try await sql.select().column("name")
            .from("movies")
            .all()
       
        print(result)
        
        return "ss"
    }
    
    /*
    var movies: [Movie] = [Movie(id: 1, name: "Superman")]
    
    // create a route group
    let movieRoutes = app.grouped("movies")
    
    // get all movies
    // http://127.0.0.1:8080/movies
    movieRoutes.get { req in
        return movies
    }
    
    // add new movie
    movieRoutes.post { req  in
        
        // validate the request
        try Movie.validate(content: req)
        
        var movie = try req.content.decode(Movie.self)
        movie.id = movies.count + 1
        
        movies.append(movie)
        // return the new movie that was just created
        return movie
    }
    
    // delete movie
    movieRoutes.delete(":movieId") { req in
        
        // get the movieId
        let movieId = req.parameters.get("movieId", as: Int.self)
        
        // Find the index of the movie to delete
        guard let index = movies.firstIndex(where: { $0.id == movieId }) else {
            throw Abort(.notFound)
        }
        
        // Remove the movie from the movies collection
        let deletedMovie = movies.remove(at: index)
        
        // return the movie that got deleted
        return deletedMovie
    }
    
    movieRoutes.put(":movieId") { req in
        
        let movieId = req.parameters.get("movieId", as: Int.self)
        
        // Find the index of the movie with the specified ID
        guard let index = movies.firstIndex(where: { $0.id == movieId }) else {
            throw Abort(.notFound)
        }
        
        // decode the request
        let updatedMovie = try req.content.decode(Movie.self)
        
        var movie = movies[index]
        movie.name = updatedMovie.name
        
        return updatedMovie
    }
     
     */
    

}
