//
//  File.swift
//  
//
//  Created by Mohammad Azam on 3/13/24.
//

import Foundation
import Vapor
import Fluent
import SQLKit

// make it into a struct
class MoviesController: RouteCollection {
    
    func boot(routes: RoutesBuilder) throws {
        
        let movies = routes.grouped("movies")
        movies.get(use: index)
        movies.post(use: create)
        
        movies.group(":movieId") { movie in
            movie.delete(use: delete)
            movie.put(use: update)
            movie.post("reviews", use: createReview)
            movie.get("reviews", use: getMovieReviews)
        }
    }
    
    func index(req: Request) async throws -> [MovieResponse] {
        
        // one movie can have many reviews
        // how can I return reviewCount for each movie
        try await Movie.query(on: req.db)
            .join(Review.self, on: \Movie.$id == \Review.$movie.$id)
            .field(\Movie.$id)
            .field(\Movie.$name)
            .unique()
            .all()
            .map { movie in
                MovieResponse(id: movie.id!, name: movie.name, reviewCount: movie.reviews.count)
            }
    }
    
    func create(req: Request) async throws -> Movie {
        
        // validate the request
        try Movie.validate(content: req)
        // decode the movie
        let movie = try req.content.decode(Movie.self)
        // save movie to the database
        try await movie.save(on: req.db)
        // return the new movie
        return movie
    }
    
    
    func delete(req: Request) async throws -> Movie {
        
        // get the movieId
        let movieId = req.parameters.get("movieId", as: UUID.self)
        
        // get the movie using the id
        guard let movie = try await Movie.find(movieId, on: req.db) else {
            throw Abort(.badRequest)
        }

        // delet the movie
        try await movie.delete(on: req.db)
        
        // return the deleted movie
        return movie
    }
    
    
    func update(req: Request) async throws -> Movie {
        
        let movieId = req.parameters.get("movieId", as: UUID.self)
        
        guard let movie = try await Movie.find(movieId, on: req.db) else {
            throw Abort(.badRequest)
        }
        
        // get the updated movie
        let updatedMovie = try req.content.decode(Movie.self)
        
        // update the fields
        movie.name = updatedMovie.name
        
        // persist the updated movie
        try await movie.update(on: req.db)
        
        // return the movie 
        return movie
    }
    
    // add a review to a movie
    // POST /movies/:movieId/reviews
    
    func createReview(req: Request) async throws -> CreateReviewResponse {
        
        // get the movieId
        let movieId = req.parameters.get("movieId", as: UUID.self)
        
        // get the movie
        guard let movie = try await Movie.find(movieId, on: req.db) else {
            throw Abort(.badRequest)
        }
        
        // decode the review
        let createReviewRequest = try req.content.decode(CreateReviewRequest.self)
        
        // create review
        let review = Review(subject: createReviewRequest.subject, description: createReviewRequest.description, movieId: movie.id!)
            
        // save the movie
        try await review.save(on: req.db)
        
        // convert to a DTO
        let createReviewResponse = CreateReviewResponse(id: review.id!, subject: review.subject, description: review.description, movieId: movieId!)
        
        return createReviewResponse
    }
    
    func getMovieReviews(req: Request) async throws -> [ReviewResponse] {
        
        // get the movieId
        let movieId = req.parameters.get("movieId", as: UUID.self)
        
        // get the movie
        guard let movie = try await Movie.find(movieId, on: req.db) else {
            throw Abort(.badRequest)
        }
        
        return try await Review.query(on: req.db)
            .with(\.$movie)
            .filter(\.$movie.$id == movie.id!)
            .all()
            .compactMap { review in
                ReviewResponse(review: review)
            }
    }
    
    
}
