//
//  File.swift
//  
//
//  Created by Mohammad Azam on 3/15/24.
//

import Foundation
import Fluent

struct CreateMoviesTableMigration: AsyncMigration {
    
    func prepare(on database: Database) async throws {
        
        try await database.schema("movies")
            .id()
            .field("name", .string, .required)
            .create()
        
    }
    
    func revert(on database: Database) async throws {
        
        try await database.schema("movies")
            .delete()
    }
}
