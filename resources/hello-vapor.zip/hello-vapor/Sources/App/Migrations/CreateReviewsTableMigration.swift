//
//  File.swift
//  
//
//  Created by Mohammad Azam on 3/16/24.
//

import Foundation
import Fluent

struct CreateReviewsTableMigration: AsyncMigration {
    
    func prepare(on database: Database) async throws {
        
        try await database.schema("reviews")
            .id()
            .field("subject", .string, .required)
            .field("description", .string, .required)
            .field("movie_id", .uuid, .required, .references("movies", "id", onDelete: .cascade))
            .create()
    }
    
    func revert(on database: Database) async throws {
        
        try await database.schema("reviews")
            .delete()
    }
}
