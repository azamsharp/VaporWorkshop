//
//  File.swift
//  
//
//  Created by Mohammad Azam on 3/16/24.
//

import Foundation
import Vapor 

struct CreateReviewRequest: Content {
    let subject: String
    let description: String
}
