//
//  File.swift
//  
//
//  Created by Mohammad Azam on 3/17/24.
//

import Foundation
import Vapor

struct CreateReviewResponse: Content {
    
    let id: UUID
    let subject: String
    let description: String
    let movieId: UUID
    
}
