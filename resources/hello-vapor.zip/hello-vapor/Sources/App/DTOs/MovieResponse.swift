//
//  File.swift
//  
//
//  Created by Mohammad Azam on 3/19/24.
//

import Foundation
import Vapor

struct MovieResponse: Content {
    let id: UUID
    let name: String
    let reviewCount: Int 
}

