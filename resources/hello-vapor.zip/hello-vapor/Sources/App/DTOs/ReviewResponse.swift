//
//  File.swift
//  
//
//  Created by Mohammad Azam on 3/18/24.
//

import Foundation
import Vapor
import Fluent

struct ReviewResponse: Content {
    
    let id: UUID
    let subject: String
    let description: String
    let movieId: UUID
    
    init?(review: Review) {
        
        guard let movieId = review.movie.id,
              let reviewId = review.id else { return nil }
        
        self.id = reviewId
        self.subject = review.subject
        self.description = review.description
        self.movieId = movieId 
        
    }
    
}
