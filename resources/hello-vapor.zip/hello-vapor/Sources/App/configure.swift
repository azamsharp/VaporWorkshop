import Vapor
import Fluent
import FluentPostgresDriver

// configures your application
public func configure(_ app: Application) async throws {
    // uncomment to serve files from /Public folder
    // app.middleware.use(FileMiddleware(publicDirectory: app.directory.publicDirectory))
    // register routes
    
    // configure the database
    app.databases.use(.postgres(configuration: SQLPostgresConfiguration(hostname: "drona.db.elephantsql.com", username: "yggpjmjl", password: "cEapAvCAiiD9ZKufyZX_6MKEyPoGbF3e", database: "yggpjmjl", tls: .prefer(try .init(configuration: .clientDefault)))), as: .psql)
    
    // register migrations
    app.migrations.add(CreateMoviesTableMigration())
    app.migrations.add(CreateReviewsTableMigration())
    
    try routes(app)
}
