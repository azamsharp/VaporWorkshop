//
//  Constants.swift
//  MovieAppClient
//
//  Created by Mohammad Azam on 3/17/24.
//

import Foundation

struct Constants {
    
    struct Urls {
        
        static let allMovies = URL(string: "http://127.0.0.1:8080/movies")!
        static let saveMovie = URL(string: "http://127.0.0.1:8080/movies")!
        
        static func saveReview(movieId: UUID) -> URL {
            URL(string: "http://127.0.0.1:8080/movies/\(movieId)/reviews")!
        }
        
        static func reviewsBy(movieId: UUID) -> URL {
            URL(string: "http://127.0.0.1:8080/movies/\(movieId)/reviews")!
        }
    }
}
