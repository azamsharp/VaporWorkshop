//
//  MovieListView.swift
//  MovieAppClient
//
//  Created by Mohammad Azam on 3/17/24.
//

import SwiftUI

struct MovieListView: View {
    
    let movies: [Movie]
    
    var body: some View {
        List(movies) { movie in
            Text(movie.name)
        }
    }
}

#Preview {
    MovieListView(movies: [])
}
