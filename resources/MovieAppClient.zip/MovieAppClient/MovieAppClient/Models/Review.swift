//
//  Review.swift
//  MovieAppClient
//
//  Created by Mohammad Azam on 3/17/24.
//

import Foundation

struct Review: Codable, Identifiable {
    var id: UUID?
    let subject: String
    let description: String
    let movieId: UUID 
}
