//
//  Movie.swift
//  MovieAppClient
//
//  Created by Mohammad Azam on 3/16/24.
//

import Foundation

struct Movie: Codable, Identifiable {
    var id: UUID?
    let name: String
}
