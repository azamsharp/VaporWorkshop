//
//  MovieStore.swift
//  MovieAppClient
//
//  Created by Mohammad Azam on 3/16/24.
//

import Foundation
import Observation

@Observable
class MovieStore {
    
    let httpClient: HTTPClient
    
    var movies: [Movie] = []
    var reviews: [Review] = []

    init(httpClient: HTTPClient) {
        self.httpClient = httpClient
    }
    
    func loadMovies() async throws {
        
        let resource = Resource(url: Constants.Urls.allMovies, modelType: [Movie].self)
        movies = try await httpClient.load(resource)
    }
    
    func saveMovie(movie: Movie) async throws {
        
        let data = try JSONEncoder().encode(movie)
        let resource = Resource(url: Constants.Urls.saveMovie, method: .post(data), modelType: Movie.self)
        let savedMovie = try await httpClient.load(resource)
        movies.append(savedMovie)
    }
    
    func saveReview(review: Review, movieId: UUID) async throws {
        
        let data = try JSONEncoder().encode(review)
        let resource = Resource(url: Constants.Urls.saveReview(movieId: movieId), method: .post(data), modelType: Review.self)
        
        let savedReview = try await httpClient.load(resource)
        reviews.append(savedReview)
    }
    
    func reviews(by movieId: UUID) -> [Review] {
        reviews.filter { $0.movieId == movieId }
    }
}
