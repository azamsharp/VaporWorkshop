//
//  HTTPClientEnvironmentKey.swift
//  MovieAppClient
//
//  Created by Mohammad Azam on 3/17/24.
//

import Foundation
import SwiftUI

private struct HTTPClientEnvironmentKey: EnvironmentKey {
  static let defaultValue = HTTPClient()
}

extension EnvironmentValues {
  var httpClient: HTTPClient {
    get { self[HTTPClientEnvironmentKey.self] }
    set { self[HTTPClientEnvironmentKey.self] = newValue }
  }
}
