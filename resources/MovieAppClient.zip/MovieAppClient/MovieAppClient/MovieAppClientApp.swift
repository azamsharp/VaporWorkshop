//
//  MovieAppClientApp.swift
//  MovieAppClient
//
//  Created by Mohammad Azam on 3/16/24.
//

import SwiftUI

@main
struct MovieAppClientApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                MovieListScreen() 
            }
            .environment(\.httpClient, HTTPClient())
        }
    }
}
