//
//  MovieListScreen.swift
//  MovieAppClient
//
//  Created by Mohammad Azam on 3/16/24.
//

import SwiftUI

struct MovieListScreen: View {
    
    @State private var isPresented: Bool = false
    @State private var movies: [Movie] = []
    
    @Environment(\.httpClient) private var httpClient
  
    private func loadMovies() async {
        
        let resource = Resource(url: Constants.Urls.allMovies, modelType: [Movie].self)
        do {
            movies = try await httpClient.load(resource)
        } catch {
            // handle error
            print(error)
        }
    }
    
    var body: some View {
        VStack {
            List(movies) { movie in
                NavigationLink {
                    MovieDetailScreen(movie: movie)
                } label: {
                    Text(movie.name)
                }
            }
            .task {
                await loadMovies()
            }
        }
        .navigationTitle("Movies")
        .toolbar(content: {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Add New Movie") {
                    isPresented = true
                }
            }
        })
        .sheet(isPresented: $isPresented, content: {
            AddMovieScreen(movies: $movies)
        })
    }
}

#Preview {
    NavigationStack {
        MovieListScreen()
    }.environment(MovieStore(httpClient: HTTPClient()))
}
