//
//  MovieDetailScreen.swift
//  MovieAppClient
//
//  Created by Mohammad Azam on 3/17/24.
//

import SwiftUI

struct MovieDetailScreen: View {
    
    let movie: Movie
    
    @Environment(\.httpClient) private var httpClient
    
    @State private var reviewSubject: String = ""
    @State private var reviewDescription: String = ""
    @State private var saving: Bool = false
    @State private var reviews: [Review] = []
    
    private func loadReviews() async {
        
        guard let movieId = movie.id else { return }
        
        let resource = Resource(url: Constants.Urls.reviewsBy(movieId: movieId), modelType: [Review].self)
        
        print(resource.url.absoluteString)
        
        do {
            reviews = try await httpClient.load(resource)
            print(reviews)
        } catch {
            print(error.localizedDescription)
        }
        
    }
    
    private func saveReview() async {
        
        do {
            
            guard let movieId = movie.id else { return }
            
            let review = Review(subject: reviewSubject, description: reviewDescription, movieId: movieId)
            
            let data = try JSONEncoder().encode(review)
            
            let resource = Resource(url: Constants.Urls.saveReview(movieId: movieId), method: .post(data), modelType: Review.self)
            
            let newReview = try await httpClient.load(resource)
            reviews.append(newReview)
            
        } catch {
            print(error)
        }
        
    }
    
    var body: some View {
        Form {
            TextField("Review subject", text: $reviewSubject)
            TextField("Review description", text: $reviewDescription)
            
            Button("Save") {
                saving = true
            }.task(id: saving) {
                if saving {
                    await saveReview()
                    saving = false
                }
            }
            
            List(reviews) { review in
                Text(review.subject)
            }
            
        }
        .task {
            await loadReviews()
        }
        
        .navigationTitle(movie.name)
    }
}

#Preview {
    NavigationStack {
        MovieDetailScreen(movie: Movie(id: UUID(uuidString: "D5B23A50-A258-480F-B2A6-D306D08AD428"), name: "Batman"))
    }
}
