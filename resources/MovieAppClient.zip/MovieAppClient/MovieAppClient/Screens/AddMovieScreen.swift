//
//  AddMovieScreen.swift
//  MovieAppClient
//
//  Created by Mohammad Azam on 3/17/24.
//

import SwiftUI

struct AddMovieScreen: View {
    
    @Binding var movies: [Movie]
    @Environment(\.httpClient) private var httpClient
    
    @Environment(\.dismiss) private var dismiss
    @State private var name: String = ""
    @State private var saving: Bool = false
    
    private func saveMovie() async {
    
        let movie = Movie(name: name)
        
        do {
            
            let data = try JSONEncoder().encode(movie)
            let resource = Resource(url: Constants.Urls.saveMovie, method: .post(data), modelType: Movie.self)
            let movie = try await httpClient.load(resource)
            movies.append(movie)
            
        } catch {
            print(error)
        }
    }
    
    var body: some View {
        Form {
            TextField("Name", text: $name)
            Button("Save") {
                saving = true
            }
        }.navigationTitle("Add New")
            .task(id: saving) {
                if saving {
                    await saveMovie()
                    saving = false
                    dismiss()
                }
            }
    }
}

